
# Chat Application - Submission Package

## 📁 Project Structure
- chatapp-backend/     → Spring Boot backend with JWT Auth, WebSocket chat, AES encryption
- chatapp-frontend/    → Frontend using HTML, CSS, JavaScript (STOMP over SockJS)

---

## ⚙️ How to Run the Project

### ✅ Backend (Spring Boot)
1. Navigate to the backend folder:
   cd chatapp-backend

2. Build and run the project using Maven:
   mvn spring-boot:run

3. Ensure MySQL is running and credentials in `application.properties` are correct.

### ✅ Frontend (JavaScript)
1. Navigate to `chatapp-frontend/`.
2. Open `index.html` (or the main file like `app.js`) in a browser.

---

## ✅ Features Included
- JWT-based user authentication
- Real-time chat via WebSockets (STOMP protocol)
- AES encryption for message security
- MySQL database integration for user and message storage

---

## 📌 Notes
- Ensure you have Java 17+ and Maven installed for backend.
- MySQL must be running with proper schema defined.
- For submission, this ZIP file is final. No modifications needed.

Prepared & Packaged for Submission ✅
